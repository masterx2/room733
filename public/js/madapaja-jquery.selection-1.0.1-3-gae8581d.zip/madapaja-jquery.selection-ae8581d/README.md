[![Code Climate](https://codeclimate.com/github/madapaja/jquery.selection.png)](https://codeclimate.com/github/madapaja/jquery.selection)

see http://madapaja.github.com/jquery.selection/
